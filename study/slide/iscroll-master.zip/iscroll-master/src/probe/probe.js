
iScroll.prototype._initProbe = function () {
	if ( this.options.probeType == 3 ) {
		this.options.useTransition = false;
	}
};
