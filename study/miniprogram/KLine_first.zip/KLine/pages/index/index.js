//index.js
const API = require('../../utils/api');
const KLine = require('../../utils/kLine/k-line');
const KTurnover = require('../../utils/kLine/k-turnover');
const KMacd = require('../../utils/kLine/k-macd');

const globalData = getApp().globalData;

Page({
    data: {
        touchStartMilliSec: -1,
        startX: 0,
        startY: 0,
        endX: 0,
        endY: 0,
        moveStartIndex: 0,
        moveStartShowDataStart: 0,
        mTimeout: null,
        maxDistance: 0,
        // 画笔
        ctx_line: null,
        ctx_turnover: null,
        ctx_macd: null,
        // k 线
        KLine: null,
        allData: [],
        showData: [],
        // 显示起点,最右边开始,往右滑是+1,往左滑-1
        showDataStart: 0,
        // 显示数据长度
        showDataLen: globalData.bn,
        // 数据是否在左边显示
        graphOnLeft: false,
        // 是否显示十字线
        showCrosshair: false,
        crossXaxis: '0px',
        crossYaxis: '0px',
        crosshairDate: '2018-03-16',
        showDataStartDate: '2018-03-01',
        showDataEndDate: '2018-03-20',
        // k 线 选择时,显示的值
        lineLabel: {
            o: '16.48',
            c: '16.47',
            h: '16.77',
            l: '16.40',
            v: '-0.15',
            f: '-0.19%'
        },
        // k 线 选择时,是否为红色
        lineLabelIsRed: {
            o: true,
            c: false,
            h: true,
            l: false,
            v: true,
            f: true
        },
        // 成交量,选择时,显示的值
        turnoverLabel: '33.12万',
        // 成交量,选择时,是否为红色
        turnoverLabelIsRed: false,
        // macd,选择时,显示的值
        macdLabel: {
            MACD: '+0.04',
            DIFF: '-0.22',
            DEA: '-0.30'
        },
        // macd,选择时,macd是否为红色
        macdLabelMACDIsRed: true
    },
    onLoad: function () {
        this.getDkData();
    },
    getDkData(stockNo) {
        API.getDkData(stockNo).then(data => {
            this.data.ctx_line = wx.createCanvasContext('k-line');
            this.data.ctx_turnover = wx.createCanvasContext('k-turnover');
            this.data.ctx_macd = wx.createCanvasContext('k-macd');
            this.data.allData = data;
            this.data.showDataStart = 0;
            this.draw();
        }).catch(err => console.error(err));
    },
    draw() {
        if (!this.data.ctx_line || !this.data.ctx_turnover || !this.data.ctx_macd) {
            return;
        }
        const allDataLen = this.data.allData.length;
        const showDataStart = allDataLen - globalData.bn - 29 - this.data.showDataStart;
        // 减去 29 , 为了计算 MA30
        const {
            maxVal_kLine,
            minVal_kLine,
            maxVal_kTurnover,
            maxVal_kMacd,
            minVal_kMacd,
            overShowDataLen
        } = this.dataProcess(this.data.allData.slice(showDataStart < 0 ? 0 : showDataStart, allDataLen - this.data.showDataStart));
        if (this.data.showData.length < 1) {
            return;
        }
        // 实际数组长度,与图表的中的 数组长度

        this.data.KLine = new KLine(
            this.data.ctx_line,
            this.data.showData,
            overShowDataLen,
            globalData.sw * 380 / 750,
            maxVal_kLine,
            minVal_kLine
        );
        new KTurnover(
            this.data.ctx_turnover,
            this.data.showData,
            overShowDataLen,
            globalData.sw * 220 / 750,
            maxVal_kTurnover
        );
        new KMacd(
            this.data.ctx_macd,
            this.data.showData,
            overShowDataLen,
            globalData.sw * 230 / 750,
            maxVal_kMacd,
            minVal_kMacd
        );

        this.data.ctx_line.draw();
        this.data.ctx_turnover.draw();
        this.data.ctx_macd.draw();
    },
    dataProcess(originData) {
        let maxVal_kLine = -Infinity;
        let minVal_kLine = Infinity;

        let maxVal_kTurnover = -Infinity;

        let maxVal_kMacd = -Infinity;
        let minVal_kMacd = Infinity;


        // 蜡烛图 数据
        this.data.showData = [];

        //"2017-01-06,17.00,17.10,17.40,16.90,1462083,25.1亿,2.95%,+12.32"
        // [日期0，开盘价1，现价2，最高价3，最低价4，成交量5，成交额6，振幅7，涨跌8]
        originData.forEach((item, index) => {
            const arr = item.trim().split(',');
            // 单个 data 数据
            let curr = {};
            if (index) {
                if (index == originData.length - 1) {
                    this.setData({
                        showDataEndDate: arr[0].trim()
                    });
                }
                const close = +arr[2];
                const last = this.data.showData[this.data.showData.length - 1];
                const EMA12 = last.EMA12 * (11 / 13) + close * (2 / 13);
                const EMA26 = last.EMA26 * (25 / 27) + close * (2 / 27);
                const DIFF = EMA12 - EMA26;
                const DEA = last.DEA * (8 / 10) + DIFF * (2 / 10);
                const MACD = 2 * (DIFF - DEA);

                curr = { date: arr[0].trim(), EMA12, EMA26, DIFF, DEA, MACD };
            } else {
                this.setData({
                    showDataStartDate: arr[0].trim()
                });
                curr = {
                    date: arr[0].trim(),
                    EMA12: +arr[2],
                    EMA26: +arr[2],
                    DIFF: 0,
                    DEA: 0,
                    MACD: 0
                };
            }


            if (index >= globalData.bn - this.data.showDataLen) {
                if (arr[3] > maxVal_kLine) {
                    maxVal_kLine = +arr[3];
                }
                if (arr[4] < minVal_kLine) {
                    minVal_kLine = +arr[4];
                }
                if (arr[5] > maxVal_kTurnover) {
                    maxVal_kTurnover = +arr[5];
                }

                (curr.DIFF > maxVal_kMacd) && (maxVal_kMacd = curr.DIFF);
                (curr.DEA > maxVal_kMacd) && (maxVal_kMacd = curr.DEA);
                (curr.MACD > maxVal_kMacd) && (maxVal_kMacd = curr.MACD);

                (curr.DIFF < minVal_kMacd) && (minVal_kMacd = curr.DIFF);
                (curr.DEA < minVal_kMacd) && (minVal_kMacd = curr.DEA);
                (curr.MACD < minVal_kMacd) && (minVal_kMacd = curr.MACD);
            }

            this.data.showData.push(Object.assign(curr, {
                open: +arr[1],
                close: +arr[2],
                high: +arr[3],
                low: +arr[4],
                volume: +arr[5],  // 成交量
                riseFall: arr[8],  // 涨跌
                amplitude: arr[7]   // 涨幅
            }));
        });

        // 图像不足一屏,显示在左边
        if (this.data.graphOnLeft) {
            this.data.showData = this.data.showData.concat(Array(Math.abs(globalData.bn - this.data.showDataLen)).fill({ invalide: true }));
        }
        return {
            maxVal_kLine,
            minVal_kLine,
            maxVal_kTurnover,
            maxVal_kMacd,
            minVal_kMacd,
            overShowDataLen: this.data.showData.length - globalData.bn
        };
    },
    // 点击图像 处理
    tapCanvas(isShow) {
        const changeObj = {};
        if (!isShow) {
            changeObj.showCrosshair = !this.data.showCrosshair;
        }

        if (isShow || changeObj.showCrosshair) {
            const index = Math.round((this.data.endX - (5 / 750) * globalData.sw - globalData.mw) / globalData.bw) - 1;
            const turnIndex = index + this.data.showData.length - globalData.bn;
            const item = this.data.showData[turnIndex];
            const lastItem = this.data.showData[turnIndex < 1 ? 0 : turnIndex - 1];
            if (index < 0 || index >= globalData.bn || item.invalide) {
                return;
            }
            if (this.data.KLine) {
                changeObj.crossYaxis = Math.round(this.data.KLine.numToYaxis(item.close)) + 'px';
            }
            changeObj.crossXaxis = Math.round(globalData.mw + globalData.bw * (index + 1) - 0.5) + 'px';

            changeObj.lineLabel = {
                o: item.open,
                c: item.close,
                h: item.high,
                l: item.low,
                v: item.riseFall,
                f: item.amplitude
            };
            // 十字线时间
            changeObj.crosshairDate = item.date;

            // 成交量
            changeObj.turnoverLabel = item.volume;
            if (changeObj.turnoverLabel > 10000) {
                changeObj.turnoverLabel = (changeObj.turnoverLabel / 10000).toFixed(2) + '万';
            }
            changeObj.macdLabel = {
                MACD: item.MACD.toFixed(3),
                DIFF: item.DIFF.toFixed(3),
                DEA: item.DEA.toFixed(3)
            }
            // 颜色相关
            // k 线 选择时,是否为红色
            changeObj.lineLabelIsRed = {
                o: item.open < lastItem.open,
                c: item.open > lastItem.open,
                h: item.open > lastItem.open,
                l: item.open < lastItem.open,
                v: +item.riseFall > 0,
                f: !/^[-—]/.test(`${item.amplitude}`.trim())
            };
            if (item.open < item.close) {
                changeObj.turnoverLabelIsRed = true;
            } else {
                changeObj.turnoverLabelIsRed = false;
            }
            if (item.MACD > 0) {
                changeObj.macdLabelMACDIsRed = true;
            } else {
                changeObj.macdLabelMACDIsRed = false;
            }
        }
        this.setData(changeObj);
    },
    // 滑动图像 处理
    swipCanvas() {
        if (!this.data.mTimeout || this.data.allData.length < 5) {
            return;
        }
        this.data.graphOnLeft = false;
        this.data.showDataLen = globalData.bn;

        let ind = Math.round((this.data.endX - (5 / 750) * globalData.sw - globalData.mw) / globalData.bw) - 1;
        ind = ind < 0 ? 0 : ind > globalData.bn - 1 ? globalData.bn : ind;

        let resInd = this.data.moveStartShowDataStart + ind - this.data.moveStartIndex;
        if (resInd > this.data.allData.length - 5) {
            this.data.showDataStart = this.data.allData.length - 5;
        } else if (resInd < 0) {
            this.data.showDataStart = resInd < 5 - globalData.bn ? 5 - globalData.bn : resInd;
            this.data.showDataLen = globalData.bn - this.data.showDataStart;
            this.data.graphOnLeft = true;
        } else {
            this.data.showDataStart = resInd;
        }
        this.draw();
    },
    // 左右滑动
    canvasTouchstart: function (e) {
        this.data.startX = e.touches[0].pageX;
        this.data.startY = e.touches[0].pageY;
        this.data.endX = e.touches[0].pageX;
        this.data.endY = e.touches[0].pageY;

        const ind = Math.round((this.data.endX - (5 / 750) * globalData.sw - globalData.mw) / globalData.bw) - 1;
        this.data.moveStartIndex = ind < 0 ? 0 : ind > globalData.bn - 1 ? globalData.bn : ind;

        this.data.touchStartMilliSec = new Date().getTime();
        this.data.maxDistance = 0;

        this.data.moveStartShowDataStart = this.data.showDataStart;
    },
    canvasTouchmove: function (e) {
        const curX = e.touches[0].pageX;
        const curY = e.touches[0].pageY;

        let dis = Math.abs(curX - this.data.startX);
        if (this.data.maxDistance < dis) {
            this.data.maxDistance = dis;
        }
        dis = Math.abs(curY - this.data.startY);
        if (this.data.maxDistance < dis) {
            this.data.maxDistance = dis;
        }

        if (Math.abs(curX - this.data.endX) > globalData.bw) {
            this.data.endX = curX;
            if (this.data.showCrosshair) {
                this.tapCanvas(true);
            } else {
                this.data.mTimeout = true;
                // clearTimeout(this.data.mTimeout);
                // this.data.mTimeout = setTimeout(() => {

                // }, 350);
                this.swipCanvas();
            }
        }
    },
    canvasTouchend: function (e) {
        this.data.mTimeout = null;
        if (this.data.maxDistance < 6) {
            const milliSecLen = new Date().getTime() - this.data.touchStartMilliSec;
            if (milliSecLen > 40 && milliSecLen < 500) {
                this.tapCanvas();
            }
        }
    }
});